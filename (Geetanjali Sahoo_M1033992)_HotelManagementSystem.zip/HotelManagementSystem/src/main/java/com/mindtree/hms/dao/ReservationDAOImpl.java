/**
 * 
 */
package com.mindtree.hms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.tomcat.util.codec.binary.StringUtils;

import com.mindtree.hms.model.ReservationVO;

/**
 * 
 */
public class ReservationDAOImpl implements ReservationDAO {

    @Override
    public boolean getUserDetails(ReservationVO reservVO) throws ClassNotFoundException, SQLException {

        Connection con;
        boolean returnValue =   false;
        try {
            con = getConnection();
            userDetails(con, reservVO);
            
        } catch (ClassNotFoundException e) {
            throw new ClassNotFoundException();
        } catch (SQLException e) {
            throw new SQLException();
        }
        returnValue =   true;
        return returnValue;
    }
    
    @Override
    public String getBookingId() throws ClassNotFoundException, SQLException {

        Connection con;
        String book_id =   "";
        try {
            con = getConnection();
            book_id =   getBookId(con);
            
        } catch (ClassNotFoundException e) {
            throw new ClassNotFoundException();
        } catch (SQLException e) {
            throw new SQLException();
        }
        return book_id;
    }
    
    @Override
    public int bookRoom(ReservationVO reserveVO) throws ClassNotFoundException, SQLException{

        Connection  con = null;
        int returnNum   =   0;
        try {
            con = getConnection();
            con.setAutoCommit(false);
            returnNum   =   bookRoom(con, reserveVO);
            if(returnNum    ==  1){
                returnNum   =   addUserDetailsForReservation(con, reserveVO);
                if(returnNum    ==  1){
                    con.commit();
                }
            }
        } catch (SQLException sqlE) {
            con.rollback();
            throw new SQLException();
        } finally{
            if (con != null) {
                con.close();
            }
        }
        return returnNum;
    }

    private Connection getConnection() throws ClassNotFoundException, SQLException {
        Connection con = null;
        try {
            Class.forName("org.postgresql.Driver");
                con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/hmsdb", "postgres", "welcome");
        } catch (ClassNotFoundException cNFE) {
            throw new ClassNotFoundException();
        } catch (SQLException sqlE) {
            throw new SQLException();
        }
        System.out.println("Opened database successfully");
        return con;
    }
    
    private void userDetails(Connection con, ReservationVO reservVO) throws SQLException {
        final String stm = "select first_name, last_name, date_of_birth, ph_number, gender, email_id, address from users where user_id = ?";
        PreparedStatement  pst = null;
        ResultSet rs = null;
        try {
            pst = con.prepareStatement(stm);
            pst.setString(1, reservVO.getUserId());
            rs = pst.executeQuery();
            while (rs.next()){
                reservVO.setFirstName(rs.getString("first_name"));
                reservVO.setLastName(rs.getString("last_name"));
                reservVO.setDateOfBirth(rs.getString("date_of_birth"));
                reservVO.setPhNumber(rs.getString("ph_number"));
                reservVO.setGender(rs.getString("gender"));
                reservVO.setEmailId(rs.getString("email_id"));
                reservVO.setAddress(rs.getString("address"));
            }
        } catch (SQLException sqlE) {
            throw new SQLException();
        }finally{
            if (rs != null) {
                rs.close();
            }
            if (pst != null) {
                pst.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }
    
    private String getBookId(Connection con) throws SQLException {
        final String stm = "select cast(max(book_id)as numeric) + 1 as book_id from reservation";
        PreparedStatement  pst = null;
        ResultSet rs = null;
        String book_id  =   "";
        try {
            pst = con.prepareStatement(stm);
            rs = pst.executeQuery();
            while (rs.next()){
                book_id =   rs.getString("book_id");
                System.out.println("book_id :: "+book_id);
            }
        } catch (SQLException sqlE) {
            throw new SQLException();
        }finally{
            if (rs != null) {
                rs.close();
            }
            if (pst != null) {
                pst.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return book_id;
    }
    
    private int bookRoom(Connection con, ReservationVO reserveVO) throws SQLException {
        final String stm = "insert into reservation (book_id, user_id, room_num, room_type, no_of_adults, no_of_minors, start_date, end_date, ref_id_type, ref_id_num) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement  pst = null;
        int result = 0;
        try {
            pst = con.prepareStatement(stm);
            pst.setString(1, reserveVO.getBookId());
            pst.setString(2, reserveVO.getUserId());
            pst.setInt(3, Integer.parseInt(reserveVO.getRoomnum()));
            pst.setString(4, reserveVO.getRoomtype());
            pst.setInt(5, Integer.parseInt(reserveVO.getNoOFAdults()));
            pst.setInt(6, Integer.parseInt(reserveVO.getNoOfMinors()));
            pst.setString(7, reserveVO.getStartDate());
            pst.setString(8, reserveVO.getEndDate());
            pst.setString(9, reserveVO.getRefIdType());
            pst.setString(10, reserveVO.getRefIdNum());
            result = pst.executeUpdate();
            System.out.println("result :: "+result);
        } catch (SQLException sqlE) {
            throw new SQLException();
        }finally{
            if (pst != null) {
                pst.close();
            }
        }
        return result;
    }

    private int addUserDetailsForReservation(Connection con, ReservationVO reserveVO) throws SQLException {
        final String stm = "insert into user_reservation (book_id, user_id, first_name, last_name, gender, ph_number, email_id, address) values (?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement  pst = null;
        int result = 0;
        try {
            pst = con.prepareStatement(stm);
            pst.setString(1, reserveVO.getBookId());
            pst.setString(2, reserveVO.getUserId());
            pst.setString(3, reserveVO.getFirstName());
            pst.setString(4, reserveVO.getLastName());
            pst.setString(5, reserveVO.getGender());
            pst.setString(6, reserveVO.getPhNumber());
            pst.setString(7, reserveVO.getEmailId());
            pst.setString(8, reserveVO.getAddress());
            result = pst.executeUpdate();
            System.out.println("result :: "+result);
        } catch (SQLException sqlE) {
            throw new SQLException();
        }finally{
            if (pst != null) {
                pst.close();
            }
        }
        return result;
    }
}
