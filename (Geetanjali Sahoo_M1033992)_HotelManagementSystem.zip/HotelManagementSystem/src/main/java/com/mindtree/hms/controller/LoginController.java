/**
 * 
 */
package com.mindtree.hms.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpSession;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.hms.model.LoginVO;
import com.mindtree.hms.service.LoginService;

/**
 * 
 */
@Controller
public class LoginController {

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String printWelcome(ModelMap model) {
        return "hello";
    }

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String loadLoginPage(ModelMap model) {
        model.addAttribute("name", "Naveen");
        return "login";
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String validateLogin(@RequestParam String loginId, @RequestParam String pwd, ModelMap model, HttpSession session) {

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("root-context.xml");
        String returnStr = "login";
        String reponseStr = "failure";

        LoginService loginService = (LoginService) context.getBean("loginService");
        LoginVO lVO = (LoginVO) context.getBean("loginVO");
        lVO.setLoginId(loginId);
        lVO.setPwd(pwd);
        boolean status = false;
        try {
            status = loginService.validateLogin(lVO);
        } catch (ClassNotFoundException cNFE) {
            lVO.setMsg("ClassNotFoundException Occured");
            System.out.println("ClassNotFoundException occured :: " + cNFE);
            cNFE.printStackTrace();
        } catch (SQLException sqlE) {
            lVO.setMsg("SQLException Occured");
            System.out.println("SQLException occured :: " + sqlE);
            sqlE.printStackTrace();
        } finally {
            context.close();
        }

        if (status) {
            returnStr = "home";
            reponseStr = "success";
        }
        session.setAttribute("LOGGED_IN_USER_NAME", lVO.getUserName());
        session.setAttribute("LOGGED_IN_USER_ID", loginId);
        model.addAttribute(reponseStr, lVO.getMsg());

        return returnStr;
    }

    @RequestMapping(value = "/home", method = RequestMethod.GET)
    public String loadHomePage(ModelMap model, HttpSession session) {
        return "home";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String loadLogoutPage(ModelMap model, HttpSession session) {
        
        // Please remove all the attributes that are saved in session before logout
        session.removeAttribute("LOGGED_IN_USER_NAME");
        session.removeAttribute("LOGGED_IN_USER_ID");
        model.addAttribute("logout", "Logged Out Successfully!");
        return "login";
    }

}
