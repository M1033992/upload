/**
 * 
 */
package com.mindtree.hms.service;

import java.sql.SQLException;

import com.mindtree.hms.model.RegistrationVO;

/**
 * 
 */
public interface RegistrationService {

    public int registerUser(RegistrationVO rVO) throws ClassNotFoundException, SQLException;

    public int updateUserDetails(RegistrationVO registerVO) throws ClassNotFoundException, SQLException;
}
