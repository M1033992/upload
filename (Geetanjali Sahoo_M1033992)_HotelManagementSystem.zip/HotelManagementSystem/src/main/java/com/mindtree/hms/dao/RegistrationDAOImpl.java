/**
 * 
 */
package com.mindtree.hms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.mindtree.hms.model.RegistrationVO;

/**
 * 
 */
public class RegistrationDAOImpl implements RegistrationDAO {

    @Override
    public int saveUserDetails(RegistrationVO rVO) throws ClassNotFoundException, SQLException {
        
        Connection con  =    getConnection();
        
        return saveUserDetails(con, rVO);
    }
    
    @Override
    public int updateUserDetails(RegistrationVO registerVO) throws ClassNotFoundException, SQLException {

        Connection con  =    getConnection();
        
        return updateUserDetails(con, registerVO);
    }

    private Connection getConnection() throws ClassNotFoundException, SQLException {
        Connection con = null;
        try {
            Class.forName("org.postgresql.Driver");
                con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/hmsdb", "postgres", "welcome");
        } catch (ClassNotFoundException cNFE) {
            throw new ClassNotFoundException();
        } catch (SQLException sqlE) {
            throw new SQLException();
        }
        System.out.println("Opened database successfully");
        return con;
    }
    
    private int saveUserDetails(Connection con, RegistrationVO rVO) throws SQLException {
        final String stm = "INSERT INTO users (user_id, user_pwd, first_name, last_name, date_of_birth, gender, ph_number, email_id, address) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?);";
        PreparedStatement  pst = null;
        int result = 0;
        try {
            pst = con.prepareStatement(stm);
            pst.setString(1, rVO.getUserId());
            pst.setString(2, rVO.getUserPwd1());
            pst.setString(3, rVO.getFirstName());
            pst.setString(4, rVO.getLastName());
            pst.setString(5, rVO.getDateOfBirth());
            pst.setString(6, rVO.getGender());
            pst.setString(7, rVO.getPhNumber());
            pst.setString(8, rVO.getEmailId());
            pst.setString(9, rVO.getAddress());
            result = pst.executeUpdate();
            System.out.println("result :: "+result);
        } catch (SQLException sqlE) {
            throw new SQLException();
        }finally{
            if (pst != null) {
                pst.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return result;
    }
    
    private int updateUserDetails(Connection con, RegistrationVO registerVO) throws SQLException {
        final String stm = "update users set user_pwd = ?, first_name = ?, last_name = ?, date_of_birth = ?, ph_number = ?, gender = ?, email_id = ?, address = ? where user_id = ?";
        PreparedStatement  pst = null;
        int result = 0;
        try {
            pst = con.prepareStatement(stm);
            pst.setString(1, registerVO.getUserPwd1());
            pst.setString(2, registerVO.getFirstName());
            pst.setString(3, registerVO.getLastName());
            pst.setString(4, registerVO.getDateOfBirth());
            pst.setString(5, registerVO.getPhNumber());
            pst.setString(6, registerVO.getGender());
            pst.setString(7, registerVO.getEmailId());
            pst.setString(8, registerVO.getAddress());
            pst.setString(9, registerVO.getUserId());
            result = pst.executeUpdate();
            System.out.println("result :: "+result);
        } catch (SQLException sqlE) {
            throw new SQLException();
        }finally{
            if (pst != null) {
                pst.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return result;
    }

}
