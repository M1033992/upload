/**
 * 
 */
package com.mindtree.hms.service;

import java.sql.SQLException;

import com.mindtree.hms.dao.ReservationDAO;
import com.mindtree.hms.model.ReservationVO;

/**
 * 
 */
public class ReservationServiceImpl implements ReservationService {

    public ReservationDAO reserveDAO;
    
    public void setReserveDAO(ReservationDAO reserveDAO) {
        this.reserveDAO = reserveDAO;
    }
    
    @Override
    public boolean getUserDetails(ReservationVO reserveVO) throws ClassNotFoundException, SQLException {
        
        return reserveDAO.getUserDetails(reserveVO);
        
    }

    @Override
    public int bookRoom(ReservationVO reserveVO) throws ClassNotFoundException, SQLException {

        reserveVO.setBookId(getBookingId());
        
        return  reserveDAO.bookRoom(reserveVO);
    }

    private String getBookingId() throws ClassNotFoundException, SQLException {
        
        return reserveDAO.getBookingId();
    }

}
