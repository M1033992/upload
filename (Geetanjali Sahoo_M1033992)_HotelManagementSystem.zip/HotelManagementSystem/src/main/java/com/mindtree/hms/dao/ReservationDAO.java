/**
 * 
 */
package com.mindtree.hms.dao;

import java.sql.SQLException;

import com.mindtree.hms.model.ReservationVO;

/**
 * 
 */
public interface ReservationDAO {

    public boolean getUserDetails(ReservationVO reservVO) throws ClassNotFoundException, SQLException;

    public String getBookingId() throws ClassNotFoundException, SQLException;

    public int bookRoom(ReservationVO reserveVO) throws ClassNotFoundException, SQLException;
}
