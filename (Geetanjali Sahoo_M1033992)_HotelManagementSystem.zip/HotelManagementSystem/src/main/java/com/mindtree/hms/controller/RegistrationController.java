/**
 * 
 */
package com.mindtree.hms.controller;

import java.sql.SQLException;

import javax.validation.Valid;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mindtree.hms.form.RegistrationForm;
import com.mindtree.hms.model.RegistrationVO;
import com.mindtree.hms.service.RegistrationService;

/**
 * 
 */
@Controller
public class RegistrationController {

    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public String loadRegistrationPage(ModelMap model) {
        model.addAttribute("name", "Naveen");
        return "registrationForm";
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String saveUserRegistration(@Valid RegistrationForm rForm,
            ModelMap model) {

        ClassPathXmlApplicationContext  context =   new ClassPathXmlApplicationContext("root-context.xml");
        String returnStr = "registrationForm";
        String reponseStr   =   "failure";
        
        RegistrationService registrationService   =   (RegistrationService) context.getBean("registrationService");
        RegistrationVO rVO =   (RegistrationVO) context.getBean("registrationVO");
        rVO.setUserId(rForm.getUserId());
        rVO.setUserPwd1(rForm.getUserPwd1());
        rVO.setUserPwd2(rForm.getUserPwd2());
        rVO.setFirstName(rForm.getfName());
        rVO.setLastName(rForm.getlName());
        rVO.setGender(rForm.getGender());
        rVO.setPhNumber(rForm.getPhNumber());
        rVO.setDateOfBirth(rForm.getDob());
        rVO.setEmailId(rForm.getEmailId());
/*        rVO.setCity(rForm.getCity());
        rVO.setState(rForm.getState());
        rVO.setNationality(rForm.getNationality());*/
        rVO.setAddress(rForm.getAddress());
        
        int status  =   0;
        try {
            status  =   registrationService.registerUser(rVO);
        } catch (ClassNotFoundException cNFE) {
            rVO.setMsg("ClassNotFoundException Occured");
            System.out.println("ClassNotFoundException occured :: "+cNFE);
            cNFE.printStackTrace();
        } catch (SQLException sqlE) {
            rVO.setMsg("SQLException Occured");
            System.out.println("SQLException occured :: "+sqlE);
            sqlE.printStackTrace();
        }finally{
            context.close();
        }
        
        if(status   ==  1){
            returnStr   =   "login";
            reponseStr  =   "success";
            rVO.setMsg("Registration Successful");
        }
        
        model.addAttribute(reponseStr, rVO.getMsg());
        
        model.addAttribute("name", "Naveen");
        
        return returnStr;
    }
    

    

}
