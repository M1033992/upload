/**
 * 
 */
package com.mindtree.hms.form;


/**
 * 
 */
public class RegistrationForm {

    private String userId;
    private String userPwd1;
    private String userPwd2;
    private String fName;
    private String lName;
    private String gender;
    private String phNumber;
    private String dob;
    private String emailId;
/*    private String city;
    private String state;
    private String nationality;*/
    private String address;
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the userPwd1
     */
    public String getUserPwd1() {
        return userPwd1;
    }
    /**
     * @param userPwd1 the userPwd1 to set
     */
    public void setUserPwd1(String userPwd1) {
        this.userPwd1 = userPwd1;
    }
    /**
     * @return the userPwd2
     */
    public String getUserPwd2() {
        return userPwd2;
    }
    /**
     * @param userPwd2 the userPwd2 to set
     */
    public void setUserPwd2(String userPwd2) {
        this.userPwd2 = userPwd2;
    }
    /**
     * @return the fName
     */
    public String getfName() {
        return fName;
    }
    /**
     * @param fName the fName to set
     */
    public void setfName(String fName) {
        this.fName = fName;
    }
    /**
     * @return the lName
     */
    public String getlName() {
        return lName;
    }
    /**
     * @param lName the lName to set
     */
    public void setlName(String lName) {
        this.lName = lName;
    }
    /**
     * @return the gender
     */
    public String getGender() {
        return gender;
    }
    /**
     * @param gender the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }
    /**
     * @return the phNumber
     */
    public String getPhNumber() {
        return phNumber;
    }
    /**
     * @param phNumber the phNumber to set
     */
    public void setPhNumber(String phNumber) {
        this.phNumber = phNumber;
    }
    /**
     * @return the dob
     */
    public String getDob() {
        return dob;
    }
    /**
     * @param dob the dob to set
     */
    public void setDob(String dob) {
        this.dob = dob;
    }
    /**
     * @return the emailId
     */
    public String getEmailId() {
        return emailId;
    }
    /**
     * @param emailId the emailId to set
     */
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }
    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }
    
}