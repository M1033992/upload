package com.mindtree.hms.dao;

public abstract class AbstractDao {

}
