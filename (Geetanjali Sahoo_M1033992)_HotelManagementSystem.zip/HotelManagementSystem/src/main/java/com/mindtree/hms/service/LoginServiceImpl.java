package com.mindtree.hms.service;

import java.sql.SQLException;

import com.mindtree.hms.dao.LoginDAO;
import com.mindtree.hms.model.LoginVO;


public class LoginServiceImpl implements LoginService {

    public LoginDAO loginDAO;
    
    public void setLoginDAO(LoginDAO loginDAO) {
        this.loginDAO = loginDAO;
    }
    
    public boolean validateLogin(LoginVO lVo) throws ClassNotFoundException, SQLException {

        boolean retValue = false;

        loginDAO.getUserDetails(lVo);

        final String userPwd  =   lVo.getPwd();
        if(userPwd  ==  null || "".equals(userPwd)){
            lVo.setMsg("User Not found");
        }else if((!lVo.getPwd().equalsIgnoreCase(userPwd))){
            lVo.setMsg("Invalid Password");
        }else{
            lVo.setMsg("Successful Login");
            retValue = true;
        }

        return retValue;
    }

}
