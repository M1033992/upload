package com.mindtree.hms.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mindtree.hms.form.RegistrationForm;
import com.mindtree.hms.model.RegistrationVO;
import com.mindtree.hms.model.ReservationVO;
import com.mindtree.hms.service.RegistrationService;
import com.mindtree.hms.service.ReservationService;

@Controller
public class UserDetailsController {

    @RequestMapping(value = "/loadUserDetails", method = RequestMethod.GET)
    public String loadUserDetailsPage(@Valid RegistrationForm registrationForm, ModelMap model, HttpSession session) {
        
        ClassPathXmlApplicationContext  context =   new ClassPathXmlApplicationContext("root-context.xml");
        String reponseStr   =   "failure";
        final String userId =   (String) session.getAttribute("LOGGED_IN_USER_ID");
        
        ReservationService reserveServisce   =   (ReservationService) context.getBean("reservationService");
        ReservationVO reserveVO =   (ReservationVO) context.getBean("reservationVO");
        
        reserveVO.setUserId(userId);
        boolean status  =   false;
        try {
            status  =   reserveServisce.getUserDetails(reserveVO);
        } catch (ClassNotFoundException cNFE) {
            reserveVO.setMsg("ClassNotFoundException Occured");
            System.out.println("ClassNotFoundException occured :: "+cNFE);
            cNFE.printStackTrace();
        } catch (SQLException sqlE) {
            reserveVO.setMsg("SQLException Occured");
            System.out.println("SQLException occured :: "+sqlE);
            sqlE.printStackTrace();
        } finally{
            context.close();
        }
        
        if(status){
            reponseStr  =   "success";
        }
        
        registrationForm.setfName(reserveVO.getFirstName());
        registrationForm.setlName(reserveVO.getLastName());
        registrationForm.setGender(reserveVO.getGender());
        registrationForm.setPhNumber(reserveVO.getPhNumber());
        registrationForm.setDob(reserveVO.getDateOfBirth());
        registrationForm.setEmailId(reserveVO.getEmailId());
        registrationForm.setAddress(reserveVO.getAddress());
        
        model.addAttribute(reponseStr, reserveVO.getMsg());
        
        return "updateUserdetail";
    }
    
    @RequestMapping(value = "/updateUserDetails", method = RequestMethod.POST)
    public String updateUserDetailsPage(@Valid RegistrationForm registrationForm, ModelMap model, HttpSession session) {
        
        ClassPathXmlApplicationContext  context =   new ClassPathXmlApplicationContext("root-context.xml");
        String reponseStr   =   "failure";
        final String userId =   (String) session.getAttribute("LOGGED_IN_USER_ID");
        
        RegistrationService registerServisce   =   (RegistrationService) context.getBean("registrationService");
        RegistrationVO registerVO =   (RegistrationVO) context.getBean("registrationVO");
        
        registerVO.setUserId(userId);
        registerVO.setUserPwd1(registrationForm.getUserPwd1());
        registerVO.setUserPwd2(registrationForm.getUserPwd2());
        registerVO.setFirstName(registrationForm.getfName());
        registerVO.setLastName(registrationForm.getlName());
        registerVO.setGender(registrationForm.getGender());
        registerVO.setPhNumber(registrationForm.getPhNumber());
        registerVO.setDateOfBirth(registrationForm.getDob());
        registerVO.setEmailId(registrationForm.getEmailId());
        registerVO.setAddress(registrationForm.getAddress());
        
        int status  =   0;
        try {
            status  =   registerServisce.updateUserDetails(registerVO);
        } catch (ClassNotFoundException cNFE) {
            registerVO.setMsg("ClassNotFoundException Occured");
            System.out.println("ClassNotFoundException occured :: "+cNFE);
            cNFE.printStackTrace();
        } catch (SQLException sqlE) {
            registerVO.setMsg("SQLException Occured");
            System.out.println("SQLException occured :: "+sqlE);
            sqlE.printStackTrace();
        } finally{
            context.close();
        }
        
        if(status == 1){
            reponseStr  =   "success";
            registerVO.setMsg("User Details Updated Successfully");
            session.setAttribute("LOGGED_IN_USER_NAME", registerVO.getFirstName() + " " + registerVO.getLastName());
        }
        
        model.addAttribute(reponseStr, registerVO.getMsg());
        
        return "updateUserdetail";
    }
}
