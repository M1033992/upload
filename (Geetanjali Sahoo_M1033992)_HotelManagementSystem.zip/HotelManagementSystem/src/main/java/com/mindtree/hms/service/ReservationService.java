/**
 * 
 */
package com.mindtree.hms.service;

import java.sql.SQLException;

import com.mindtree.hms.model.ReservationVO;

/**
 * 
 */
public interface ReservationService {
    
    public boolean getUserDetails(ReservationVO reserveVO) throws ClassNotFoundException, SQLException;

    public int bookRoom(ReservationVO reserveVO) throws ClassNotFoundException, SQLException;

}
