/**
 * 
 */
package com.mindtree.hms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

import com.mindtree.hms.model.LoginVO;

@Repository
public class LoginDAOImpl implements LoginDAO {
    @Override
    public void getUserDetails(LoginVO lVo) throws ClassNotFoundException, SQLException {
        
        Connection con  =    getConnection();
        getUserPwd(con, lVo);
        
    }

    private Connection getConnection() throws ClassNotFoundException, SQLException {
        Connection con = null;
        try {
            Class.forName("org.postgresql.Driver");
                con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/hmsdb", "postgres", "welcome");
        } catch (ClassNotFoundException cNFE) {
            throw new ClassNotFoundException();
        } catch (SQLException sqlE) {
            throw new SQLException();
        }
        System.out.println("Opened database successfully");
        return con;
    }
    
    private void getUserPwd(Connection con, LoginVO lVo) throws SQLException {
        final String stm = "SELECT user_pwd, first_name, last_name FROM users WHERE user_id=?";
        PreparedStatement  pst = null;
        ResultSet rs = null;
        String pwd = "";
        String userName =   "";
        try {
            pst = con.prepareStatement(stm);
            pst.setString(1, lVo.getLoginId());
            rs = pst.executeQuery();
            while (rs.next()){
                pwd = rs.getString(1);
                userName = rs.getString(2) + " " + rs.getString(3);
            }
            System.out.println("pwd :: "+pwd);
        } catch (SQLException sqlE) {
            throw new SQLException();
        }finally{
            if (rs != null) {
                rs.close();
            }
            if (pst != null) {
                pst.close();
            }
            if (con != null) {
                con.close();
            }
        }
        lVo.setPwd(pwd);
        lVo.setUserName(userName);
    }
}
