package com.mindtree.hms.service;

import java.sql.SQLException;

import com.mindtree.hms.model.LoginVO;

public interface LoginService {
    public boolean validateLogin(LoginVO lVO)  throws ClassNotFoundException, SQLException;
}
