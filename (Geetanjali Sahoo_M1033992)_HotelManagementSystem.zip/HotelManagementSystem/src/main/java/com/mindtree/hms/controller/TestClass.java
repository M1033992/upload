/**
 * 
 */
package com.mindtree.hms.controller;

import java.net.URL;

/**
 * 
 */
public class TestClass {

    /**
     * @param args
     */
    public static void main(String[] args) {

        ClassLoader cl  =   LoginController.class.getClassLoader();
        URL res =   cl.getResource("/WEB-INF/root-context.xml");
        System.out.println("res :: "+res);
    }

}
