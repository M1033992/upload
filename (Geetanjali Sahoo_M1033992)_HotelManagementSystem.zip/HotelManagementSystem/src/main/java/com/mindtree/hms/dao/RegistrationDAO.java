/**
 * 
 */
package com.mindtree.hms.dao;

import java.sql.SQLException;

import com.mindtree.hms.model.RegistrationVO;

/**
 * 
 */
public interface RegistrationDAO {
    
    int saveUserDetails(RegistrationVO rVO) throws ClassNotFoundException, SQLException ;

    int updateUserDetails(RegistrationVO registerVO) throws ClassNotFoundException, SQLException ;

}
