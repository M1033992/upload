/**
 * 
 */
package com.mindtree.hms.model;

/**
 * 
 */
public class RegistrationVO {

    private String userId;
    private String userPwd1;
    private String userPwd2;
    private String firstName;
    private String lastName;
    private String gender;
    private String phNumber;
    private String dateOfBirth;
    private String emailId;
/*    private String city;
    private String State;
    private String nationality;*/
    private String address;
    private String Msg;

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return the userPwd1
     */
    public String getUserPwd1() {
        return userPwd1;
    }

    /**
     * @param userPwd1 the userPwd1 to set
     */
    public void setUserPwd1(String userPwd1) {
        this.userPwd1 = userPwd1;
    }

    /**
     * @return the userPwd2
     */
    public String getUserPwd2() {
        return userPwd2;
    }

    /**
     * @param userPwd2 the userPwd2 to set
     */
    public void setUserPwd2(String userPwd2) {
        this.userPwd2 = userPwd2;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName
     *            the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName
     *            the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * @param gender
     *            the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * @return the phNumber
     */
    public String getPhNumber() {
        return phNumber;
    }

    /**
     * @param phNumber
     *            the phNumber to set
     */
    public void setPhNumber(String phNumber) {
        this.phNumber = phNumber;
    }

    /**
     * @return the dateOfBirth
     */
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * @param dateOfBirth
     *            the dateOfBirth to set
     */
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * @return the emailId
     */
    public String getEmailId() {
        return emailId;
    }

    /**
     * @param emailId the emailId to set
     */
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the msg
     */
    public String getMsg() {
        return Msg;
    }

    /**
     * @param msg the msg to set
     */
    public void setMsg(String msg) {
        Msg = msg;
    }
}
