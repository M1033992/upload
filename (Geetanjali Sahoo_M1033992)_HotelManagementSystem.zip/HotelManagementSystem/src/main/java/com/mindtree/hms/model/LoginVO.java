/**
 * 
 */
package com.mindtree.hms.model;

/**
 * 
 */

public class LoginVO {

    private String loginId;
    private String pwd;
    private String UserName;
    private String msg;
    
    /**
     * @return the loginId
     */
    public String getLoginId() {
        return loginId;
    }
    
    /**
     * @param loginId the loginId to set
     */
    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }
    
    /**
     * @return the pwd
     */
    public String getPwd() {
        return pwd;
    }
   
    /**
     * @param pwd the pwd to set
     */
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
    
    /**
     * @return the userName
     */
    public String getUserName() {
        return UserName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        UserName = userName;
    }

    /**
     * @return the msg
     */
    public String getMsg() {
        return msg;
    }
    
    /**
     * @param msg the msg to set
     */
    public void setMsg(String msg) {
        this.msg = msg;
    }
}
