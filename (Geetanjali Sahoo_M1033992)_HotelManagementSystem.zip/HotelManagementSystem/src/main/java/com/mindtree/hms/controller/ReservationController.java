/**
 * 
 */
package com.mindtree.hms.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mindtree.hms.form.ReservationForm;
import com.mindtree.hms.model.ReservationVO;
import com.mindtree.hms.service.ReservationService;

/**
 * 
 */
@Controller
public class ReservationController {

    @RequestMapping(value = "/goToReservation", method = RequestMethod.GET)
    public String loadLoginPage(@Valid ReservationForm reserveForm, ModelMap model, HttpSession session) {
        
        ClassPathXmlApplicationContext  context =   new ClassPathXmlApplicationContext("root-context.xml");
        String reponseStr   =   "failure";
        final String userId =   (String) session.getAttribute("LOGGED_IN_USER_ID");
        
        ReservationService reserveService   =   (ReservationService) context.getBean("reservationService");
        ReservationVO reserveVO =   (ReservationVO) context.getBean("reservationVO");
        
        reserveVO.setUserId(userId);
        boolean status  =   false;
        try {
            status  =   reserveService.getUserDetails(reserveVO);
        } catch (ClassNotFoundException cNFE) {
            reserveVO.setMsg("ClassNotFoundException Occured");
            System.out.println("ClassNotFoundException occured :: "+cNFE);
            cNFE.printStackTrace();
        } catch (SQLException sqlE) {
            reserveVO.setMsg("SQLException Occured");
            System.out.println("SQLException occured :: "+sqlE);
            sqlE.printStackTrace();
        } finally{
            context.close();
        }
        
        if(status){
            reponseStr  =   "success";
        }
        reserveForm.setfName(reserveVO.getFirstName());
        reserveForm.setlName(reserveVO.getLastName());
        reserveForm.setGender(reserveVO.getGender());
        reserveForm.setPhNumber(reserveVO.getPhNumber());
        /*reserveForm.setDob(reserveVO.getDateOfBirth());
        reserveForm.setCity(reserveVO.getCity());
        reserveForm.setState(reserveVO.getState());
        reserveForm.setNationality(reserveVO.getNationality());*/
        reserveForm.setEmailId(reserveVO.getEmailId());
        reserveForm.setAddress(reserveVO.getAddress());
        
        model.addAttribute("name", "Naveen");
        model.addAttribute(reponseStr, reserveVO.getMsg());
        
        return "roombooking";
    }
    
    @RequestMapping(value = "/bookRoom", method = RequestMethod.POST)
    public String bookRoomAction(@Valid ReservationForm reserveForm, ModelMap model, HttpSession session) {
        
        ClassPathXmlApplicationContext  context =   new ClassPathXmlApplicationContext("root-context.xml");
        String reponseStr   =   "failure";
        final String userId =   (String) session.getAttribute("LOGGED_IN_USER_ID");
        
        ReservationService reserveService   =   (ReservationService) context.getBean("reservationService");
        ReservationVO reserveVO =   (ReservationVO) context.getBean("reservationVO");
        
        //User details for room booking
        reserveVO.setUserId(userId);
        reserveVO.setFirstName(reserveForm.getfName());
        reserveVO.setLastName(reserveForm.getlName());
        reserveVO.setGender(reserveForm.getGender());
        reserveVO.setPhNumber(reserveForm.getPhNumber());
        reserveVO.setEmailId(reserveForm.getEmailId());
        reserveVO.setAddress(reserveForm.getAddress());
        
        // Room Details
        reserveVO.setRoomnum(reserveForm.getRoomnum());
        reserveVO.setRoomtype(reserveForm.getRoomtype());
        reserveVO.setNoOFAdults(reserveForm.getAdultnos());
        reserveVO.setNoOfMinors(reserveForm.getMinors());
        reserveVO.setStartDate(reserveForm.getStartDate());
        reserveVO.setEndDate(reserveForm.getEndDate());
        reserveVO.setRefIdType(reserveForm.getIdtype());
        reserveVO.setRefIdNum(reserveForm.getIdnum());
        
        int status  =   0;
        try {
            status  =   reserveService.bookRoom(reserveVO);
        } catch (ClassNotFoundException cNFE) {
            reserveVO.setMsg("ClassNotFoundException Occured");
            System.out.println("ClassNotFoundException occured :: "+cNFE);
            cNFE.printStackTrace();
        } catch (SQLException sqlE) {
            reserveVO.setMsg("SQLException Occured");
            System.out.println("SQLException occured :: "+sqlE);
            sqlE.printStackTrace();
        } finally{
            context.close();
        }
        
        if(status   ==  1){
            reponseStr  =   "success";
            reserveVO.setMsg("Reservation Successful");
        }
       
        
        model.addAttribute("name", "Naveen");
        model.addAttribute(reponseStr, reserveVO.getMsg());
        
        return "roombooking";
    }
}
