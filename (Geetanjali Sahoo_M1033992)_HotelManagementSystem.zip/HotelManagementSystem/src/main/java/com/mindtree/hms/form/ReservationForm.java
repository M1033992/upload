/**
 * 
 */
package com.mindtree.hms.form;

/**
 * 
 */
public class ReservationForm extends RegistrationForm{

    private String roomnum;
    private String roomtype;
    private String adultnos;
    private String minors;
    private String startDate;
    private String endDate;
    private String idtype;
    private String idnum;
    /**
     * @return the roomnum
     */
    public String getRoomnum() {
        return roomnum;
    }
    /**
     * @param roomnum the roomnum to set
     */
    public void setRoomnum(String roomnum) {
        this.roomnum = roomnum;
    }
    /**
     * @return the roomtype
     */
    public String getRoomtype() {
        return roomtype;
    }
    /**
     * @param roomtype the roomtype to set
     */
    public void setRoomtype(String roomtype) {
        this.roomtype = roomtype;
    }
    /**
     * @return the adultnos
     */
    public String getAdultnos() {
        return adultnos;
    }
    /**
     * @param adultnos the adultnos to set
     */
    public void setAdultnos(String adultnos) {
        this.adultnos = adultnos;
    }
    /**
     * @return the minors
     */
    public String getMinors() {
        return minors;
    }
    /**
     * @param minors the minors to set
     */
    public void setMinors(String minors) {
        this.minors = minors;
    }
    /**
     * @return the startDate
     */
    public String getStartDate() {
        return startDate;
    }
    /**
     * @param startDate the startDate to set
     */
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    /**
     * @return the endDate
     */
    public String getEndDate() {
        return endDate;
    }
    /**
     * @param endDate the endDate to set
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    /**
     * @return the idtype
     */
    public String getIdtype() {
        return idtype;
    }
    /**
     * @param idtype the idtype to set
     */
    public void setIdtype(String idtype) {
        this.idtype = idtype;
    }
    /**
     * @return the idnum
     */
    public String getIdnum() {
        return idnum;
    }
    /**
     * @param idnum the idnum to set
     */
    public void setIdnum(String idnum) {
        this.idnum = idnum;
    }

}
