/**
 * 
 */
package com.mindtree.hms.service;

import java.sql.SQLException;

import com.mindtree.hms.dao.RegistrationDAO;
import com.mindtree.hms.model.RegistrationVO;

/**
 * 
 */
public class RegistrationServiceImpl implements RegistrationService {
    
    public RegistrationDAO registrationDAO;
    
    public void setRegistrationDAO(RegistrationDAO registrationDAO) {
        this.registrationDAO = registrationDAO;
    }

    @Override
    public int registerUser(RegistrationVO rVO) throws ClassNotFoundException, SQLException {
        
        int retValue    =   0;
        if(rVO.getUserId()   ==   null){
            rVO.setMsg("UserId Cannot be null!");
        } else if(rVO.getUserPwd1()   ==   null){
            rVO.setMsg("Password Cannot be null!");
        } else if(!(rVO.getUserPwd1().equals(rVO.getUserPwd2()))){
            rVO.setMsg("Both Passwords Should be same!");
        } else if(rVO.getGender()   ==  null){
            rVO.setMsg("Gender Feild must have either M, F or O value only!");
        } else if(rVO.getGender().length()  > 1){
            rVO.setMsg("Gender Feild must have either M, F or O value only!");
        } else if(rVO.getFirstName()   ==   null){
            rVO.setMsg("First Name Cannot be null!");
        } else if(rVO.getLastName()   ==   null){
            rVO.setMsg("Last Name Cannot be null!");
        } else if(rVO.getPhNumber() ==  null){
            rVO.setMsg("Phone Number cannot be null!");
        } else if(rVO.getDateOfBirth()   ==   null){
            rVO.setMsg("Date of Birth Cannot be null!");
        } else if(rVO.getEmailId()   ==   null){
            rVO.setMsg("Email Id Cannot be null!");
      /*} else if(rVO.getState() ==  null){
            rVO.setMsg("State cannot be null!");
        } else if(rVO.getNationality()   ==   null){
            rVO.setMsg("Nationality Cannot be null!");*/
        } else if(rVO.getAddress() ==  null){
            rVO.setMsg("Address cannot be null!");
        } else{
            retValue    =   registrationDAO.saveUserDetails(rVO);
        }

        return retValue;
    }

    @Override
    public int updateUserDetails(RegistrationVO registerVO) throws ClassNotFoundException, SQLException {
        
        int retValue    =   0;
        if(registerVO.getUserPwd1()   ==   null || "".equals(registerVO.getUserPwd1())){
            registerVO.setMsg("Password Cannot be null! or empty");
        } else if(!(registerVO.getUserPwd1().equals(registerVO.getUserPwd2()))){
            registerVO.setMsg("Both Passwords Should be same!");
        } else if(registerVO.getGender()   ==  null || "".equals(registerVO.getUserPwd1())){
            registerVO.setMsg("Gender Feild must have either M, F or O value only!");
        }  else if(registerVO.getGender().length()  > 1){
            registerVO.setMsg("Gender Feild must have either M, F or O value only!");
        } else if(registerVO.getFirstName()   ==   null){
            registerVO.setMsg("First Name Cannot be null!");
        } else if(registerVO.getLastName()   ==   null){
            registerVO.setMsg("Last Name Cannot be null!");
        } else if(registerVO.getPhNumber() ==  null){
            registerVO.setMsg("Phone Number cannot be null!");
        } else if(registerVO.getDateOfBirth()   ==   null){
            registerVO.setMsg("Date of Birth Cannot be null!");
        } else if(registerVO.getEmailId()   ==   null){
            registerVO.setMsg("Email Id Cannot be null!"); 
        }else if(registerVO.getAddress() ==  null){
            registerVO.setMsg("Address cannot be null!");
        } else{
            retValue    =   registrationDAO.updateUserDetails(registerVO);
        }

        return retValue;
    }

}