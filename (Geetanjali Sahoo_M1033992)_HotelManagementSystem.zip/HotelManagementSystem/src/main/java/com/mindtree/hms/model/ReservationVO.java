/**
 * 
 */
package com.mindtree.hms.model;

/**
 * 
 */
public class ReservationVO extends RegistrationVO{

    private String bookId;
    private String roomnum;
    private String roomtype;
    private String noOFAdults;
    private String noOfMinors;
    private String startDate;
    private String endDate;
    private String refIdType;
    private String refIdNum;
    
    /**
     * @return the bookId
     */
    public String getBookId() {
        return bookId;
    }
    /**
     * @param bookId the bookId to set
     */
    public void setBookId(String bookId) {
        this.bookId = bookId;
    }
    /**
     * @return the roomnum
     */
    public String getRoomnum() {
        return roomnum;
    }
    /**
     * @param roomnum the roomnum to set
     */
    public void setRoomnum(String roomnum) {
        this.roomnum = roomnum;
    }
    /**
     * @return the roomtype
     */
    public String getRoomtype() {
        return roomtype;
    }
    /**
     * @param roomtype the roomtype to set
     */
    public void setRoomtype(String roomtype) {
        this.roomtype = roomtype;
    }
    /**
     * @return the noOFAdults
     */
    public String getNoOFAdults() {
        return noOFAdults;
    }
    /**
     * @param noOFAdults the noOFAdults to set
     */
    public void setNoOFAdults(String noOFAdults) {
        this.noOFAdults = noOFAdults;
    }
    /**
     * @return the noOfMinors
     */
    public String getNoOfMinors() {
        return noOfMinors;
    }
    /**
     * @param noOfMinors the noOfMinors to set
     */
    public void setNoOfMinors(String noOfMinors) {
        this.noOfMinors = noOfMinors;
    }
    /**
     * @return the startDate
     */
    public String getStartDate() {
        return startDate;
    }
    /**
     * @param startDate the startDate to set
     */
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    /**
     * @return the endDate
     */
    public String getEndDate() {
        return endDate;
    }
    /**
     * @param endDate the endDate to set
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    /**
     * @return the refIdType
     */
    public String getRefIdType() {
        return refIdType;
    }
    /**
     * @param refIdType the refIdType to set
     */
    public void setRefIdType(String refIdType) {
        this.refIdType = refIdType;
    }
    /**
     * @return the refIdNum
     */
    public String getRefIdNum() {
        return refIdNum;
    }
    /**
     * @param refIdNum the refIdNum to set
     */
    public void setRefIdNum(String refIdNum) {
        this.refIdNum = refIdNum;
    }

}
