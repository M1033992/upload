/**
 * 
 */
package com.mindtree.hms.dao;

import java.sql.SQLException;

import com.mindtree.hms.model.LoginVO;

/**
 * 
 */
public interface LoginDAO {

    void getUserDetails(LoginVO lVo)  throws ClassNotFoundException, SQLException;

}
