--PostGreSQL Details:
--SuperUser Pwd: welcome
--Port: 5432
--Locale: [Default locale]

-- Database: hmsdb

-- DROP DATABASE hmsdb;

CREATE DATABASE hmsdb
  WITH OWNER = postgres
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'English_India.1252'
       LC_CTYPE = 'English_India.1252'
       CONNECTION LIMIT = -1;
  
-- Table: users

-- DROP TABLE users;

CREATE TABLE users
(
  user_id text NOT NULL,
  user_pwd text NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  date_of_birth text NOT NULL,
  ph_number text NOT NULL,
  gender character(1) NOT NULL,
  email_id text NOT NULL,
  address text NOT NULL,
  CONSTRAINT users_pkey PRIMARY KEY (user_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE users
  OWNER TO postgres;


INSERT INTO users (user_id, user_pwd, first_name, last_name, date_of_birth, gender, ph_number, email_id, address) VALUES('M1027628', 'naveenTest', 'Naveen', 'Basavaraj', '27/03/1989', 'M', '9535600229', 'naveen.basavarajappa@mindtree.com', 'Bengaluru');
INSERT INTO users (user_id, user_pwd, first_name, last_name, date_of_birth, gender, ph_number, email_id, address) VALUES('admin', 'admin', 'AdminUser', 'AdminUser', '27/03/1989', 'M', '123456789', 'AdminUser.AdminUser@mindtree.com', 'Bengaluru');
INSERT INTO users (user_id, user_pwd, first_name, last_name, date_of_birth, gender, ph_number, email_id, address) VALUES('tester', 'tester', 'TestUser', 'TestUser', '27/03/1989', 'M', '123456789', 'TestUser.TestUser@mindtree.com', 'Bengaluru');
INSERT INTO users (user_id, user_pwd, first_name, last_name, date_of_birth, gender, ph_number, email_id, address) VALUES('guest', 'guest', 'GuestUser', 'GuestUser', '27/03/1989', 'M', '123456789', 'GuestUser.GuestUser@mindtree.com', 'Bengaluru');

-- Table: reservation

-- DROP TABLE reservation;

CREATE TABLE reservation
(
  book_id text NOT NULL,
  user_id text NOT NULL,
  room_num numeric(5,0) NOT NULL,
  room_type text NOT NULL,
  no_of_adults numeric(3,0) NOT NULL DEFAULT 0,
  no_of_minors numeric(3,0) NOT NULL DEFAULT 0,
  end_date text NOT NULL,
  start_date text NOT NULL,
  ref_id_type text NOT NULL,
  ref_id_num text NOT NULL,
  CONSTRAINT "reservation_pkey" PRIMARY KEY (book_id),
  CONSTRAINT "reservation_user_id_fkey" FOREIGN KEY (user_id)
      REFERENCES users (user_id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE
);
ALTER TABLE reservation
  OWNER TO postgres;

insert into reservation (book_id, user_id, room_num, room_type, no_of_adults, no_of_minors, start_date, end_date, ref_id_type, ref_id_num) values ('1000', 'A188109', '100', 'AC', '2', '1', '14/12/2016', '16/12/2016', 'PAN CARD', 'ANVPN4540L');
insert into reservation (book_id, user_id, room_num, room_type, no_of_adults, no_of_minors, start_date, end_date, ref_id_type, ref_id_num) values ('1001', 'A188109', '103', 'AC', '2', '1', '15/12/2016', '17/12/2016', 'PAN CARD', 'ANVNG0140L');

-- Table: user_reservation

-- DROP TABLE user_reservation;

CREATE TABLE user_reservation
(
  user_id text NOT NULL,
  book_id text NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  gender character(1) NOT NULL,
  ph_number text NOT NULL,
  email_id text NOT NULL,
  address text NOT NULL,
  CONSTRAINT user_reservation_book_id_fkey FOREIGN KEY (book_id)
      REFERENCES reservation (book_id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT user_reservation_user_id_fkey FOREIGN KEY (user_id)
      REFERENCES users (user_id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE
);
ALTER TABLE user_reservation
  OWNER TO postgres;
